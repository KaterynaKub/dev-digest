---
name: Test Quality Skill (Imported Sample)
description: Sample skill demonstrating the archive import path -- flags test-quality gaps in a diff.
type: rubric
---

# Test Quality Skill (Imported Sample)

This is a demo skill bundled inside a .zip to exercise the archive import
path end to end. It intentionally ships alongside `install.sh` and
`run.js` in the same archive to demonstrate that the import parser never
opens or executes non-`.md` entries -- only `SKILL.md` is read.

## Rule

Flag any new test that does not assert on the specific behaviour the diff
changed.
