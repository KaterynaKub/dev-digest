// This file exists ONLY to prove the skills importer never executes archive
// contents. It is inert -- the import path never opens, reads, or runs it.
console.log('if you see this printed, something executed a file it should not have');
